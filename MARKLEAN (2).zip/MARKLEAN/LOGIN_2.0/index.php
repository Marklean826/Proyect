<?php
    header('Location: view/interfaces/index.html')
?>