print("veo gay")
