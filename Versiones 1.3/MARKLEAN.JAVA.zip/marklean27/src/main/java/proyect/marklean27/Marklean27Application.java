package proyect.marklean27;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Marklean27Application {

	public static void main(String[] args) {
		SpringApplication.run(Marklean27Application.class, args);
	}

}
