
package proyect.marklean27.Servicio;

import java.util.List;
import proyect.marklean27.Entidad.ClienteEntidad;



public interface ClienteServicio {
    
    public List<ClienteEntidad> listarCliente();
}
