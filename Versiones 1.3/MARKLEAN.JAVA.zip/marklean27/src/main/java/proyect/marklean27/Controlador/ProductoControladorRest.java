/*package proyect.marklean27.Controlador;


import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import proyect.marklean27.Entidad.ProductoEntidad;
import proyect.marklean27.Servicio.ProductoServicio;
//import proyect.marklean27.Servicio.ProductoServicioImpl;

/*@RestController
public class ProductoControladorRest {
    private final ProductoServicioImpl productoServicio;

    public ProductoControladorRest(ProductoServicioImpl productoServicio) {
        this.productoServicio = productoServicio;
    }

    @GetMapping("/obtenerProductos")
    public List<ProductoEntidad> listarProducto() {
        return productoServicio.listarProducto();
    }
}*/

/*@RestController
public class ProductoControladorRest {
    private final ProductoServicio Servicio;

    public ProductoControladorRest(ProductoServicio Servicio) {
        this.Servicio = Servicio;
    }

    @GetMapping("/obtenerProductos")
    public List<ProductoEntidad> listarProducto() {
        return Servicio.listarProducto();
    } 
}*/
