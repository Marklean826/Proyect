package proyect.marklean27.Servicio;

import java.util.List;
import proyect.marklean27.Entidad.VentaEntidad;

public interface VentaServicio {
    List<VentaEntidad> listarVentas();
}
