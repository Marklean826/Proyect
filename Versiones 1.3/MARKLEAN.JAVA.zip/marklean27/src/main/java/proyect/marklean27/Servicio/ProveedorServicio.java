package proyect.marklean27.Servicio;

import java.util.List;
import proyect.marklean27.Entidad.ProveedorEntidad;

public interface ProveedorServicio {
    List<ProveedorEntidad> listarProveedor();
}
